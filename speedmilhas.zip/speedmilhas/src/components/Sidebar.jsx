const NAV = [
  { id: 'vendas',        label: 'Vendas',             icon: '✈️' },
  { id: 'boleto',        label: 'Gerador de Boletos',  icon: '🧾' },
  { id: 'atendimento',   label: 'Atendimento',         icon: '⏱'  },
  { id: 'followup',      label: 'Follow-up',           icon: '📋' },
  { id: 'retarificacao', label: 'Retarificação',       icon: '🚨' },
]

const NAV_ADMIN = [
  { id: 'admin',         label: 'Painel Admin',        icon: '👥' },
  { id: 'configuracoes', label: 'Configurações',       icon: '⚙️' },
]

export default function Sidebar({ user, page, setPage, onLogout, collapsed, setCollapsed }) {
  const isAdmin = user?.role === 'admin'

  return (
    <div style={{
      width: collapsed ? 56 : 240,
      minHeight: '100vh',
      background: '#fff',
      borderRight: '1px solid #E5E7EB',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      transition: 'width .2s',
      overflow: 'hidden',
    }}>

      {/* Header */}
      <div style={{
        height: 56,
        display: 'flex',
        alignItems: 'center',
        padding: '0 14px',
        borderBottom: '1px solid #E5E7EB',
        gap: 10,
        flexShrink: 0,
      }}>
        <div style={{
          width: 28, height: 28,
          background: '#1A56DB',
          borderRadius: 8,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, flexShrink: 0,
        }}>✈️</div>

        {!collapsed && (
          <span style={{ fontSize: 15, fontWeight: 700, color: '#111827', whiteSpace: 'nowrap' }}>
            Speedmilhas
          </span>
        )}

        <button
          onClick={() => setCollapsed(!collapsed)}
          style={{
            marginLeft: 'auto',
            background: 'none', border: 'none',
            cursor: 'pointer', color: '#9CA3AF',
            padding: 4, borderRadius: 6, flexShrink: 0,
            fontSize: 16,
          }}
        >
          {collapsed ? '»' : '«'}
        </button>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '8px 0', overflowY: 'auto', overflowX: 'hidden' }}>
        {NAV.map(item => (
          <NavItem
            key={item.id}
            item={item}
            active={page === item.id}
            collapsed={collapsed}
            onClick={() => setPage(item.id)}
          />
        ))}

        {isAdmin && (
          <>
            <div style={{ height: 1, background: '#F3F4F6', margin: '6px 16px' }} />
            {!collapsed && (
              <div style={{
                fontSize: 10, fontWeight: 600, color: '#9CA3AF',
                textTransform: 'uppercase', letterSpacing: '.06em',
                padding: '8px 16px 4px',
              }}>
                Administração
              </div>
            )}
            {NAV_ADMIN.map(item => (
              <NavItem
                key={item.id}
                item={item}
                active={page === item.id}
                collapsed={collapsed}
                onClick={() => setPage(item.id)}
              />
            ))}
          </>
        )}
      </nav>

      {/* Footer */}
      <div style={{
        padding: '12px 14px',
        borderTop: '1px solid #E5E7EB',
        display: 'flex', alignItems: 'center',
        gap: 10, overflow: 'hidden',
      }}>
        <div style={{
          width: 32, height: 32,
          background: '#EFF6FF', borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 700, color: '#1A56DB', flexShrink: 0,
        }}>
          {user?.nome?.charAt(0).toUpperCase() || '?'}
        </div>

        {!collapsed && (
          <div style={{ overflow: 'hidden', flex: 1 }}>
            <div style={{
              fontSize: 13, fontWeight: 500, color: '#111827',
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
            }}>
              {user?.nome}
            </div>
            <div style={{ fontSize: 11, color: '#9CA3AF' }}>
              {user?.role === 'admin' ? 'Administrador' : 'Usuário'}
            </div>
          </div>
        )}

        <button
          onClick={onLogout}
          title="Sair"
          style={{
            background: 'none', border: 'none',
            cursor: 'pointer', color: '#9CA3AF',
            padding: 4, borderRadius: 6, flexShrink: 0, fontSize: 16,
          }}
        >🚪</button>
      </div>
    </div>
  )
}

function NavItem({ item, active, collapsed, onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '9px 16px', cursor: 'pointer',
        background: active ? '#EFF6FF' : 'transparent',
        borderLeft: active ? '3px solid #1A56DB' : '3px solid transparent',
        transition: 'all .15s',
        whiteSpace: 'nowrap', overflow: 'hidden',
      }}
    >
      <span style={{ fontSize: 16, flexShrink: 0 }}>{item.icon}</span>
      {!collapsed && (
        <span style={{
          fontSize: 13,
          fontWeight: active ? 600 : 500,
          color: active ? '#1A56DB' : '#374151',
        }}>
          {item.label}
        </span>
      )}
    </div>
  )
}
