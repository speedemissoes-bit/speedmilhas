import { useState } from 'react'
import Sidebar from './Sidebar'

const TITLES = {
  vendas: 'Vendas',
  boleto: 'Gerador de Boletos',
  atendimento: 'Atendimento',
  followup: 'Follow-up',
  retarificacao: 'Retarificação',
  admin: 'Painel Admin',
  configuracoes: 'Configurações',
}

export default function Layout({ user, page, setPage, onLogout, children }) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar
        user={user}
        page={page}
        setPage={setPage}
        onLogout={onLogout}
        collapsed={collapsed}
        setCollapsed={setCollapsed}
      />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflowY: 'auto' }}>
        <div style={{
          height: 56,
          background: '#fff',
          borderBottom: '1px solid #E5E7EB',
          display: 'flex',
          alignItems: 'center',
          padding: '0 24px',
          flexShrink: 0,
        }}>
          <span style={{ fontSize: 15, fontWeight: 600, color: '#111827' }}>
            {TITLES[page] || page}
          </span>
        </div>
        <div style={{ flex: 1, padding: 24 }}>
          {children}
        </div>
      </div>
    </div>
  )
}
