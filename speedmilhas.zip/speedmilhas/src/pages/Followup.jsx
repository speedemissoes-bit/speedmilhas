export default function Followup() {
  return <div style={{ color: '#6B7280', fontSize: 14 }}>Followup — em construção.</div>
}
