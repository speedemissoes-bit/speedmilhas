export default function Boleto() {
  return <div style={{ color: '#6B7280', fontSize: 14 }}>Boleto — em construção.</div>
}
