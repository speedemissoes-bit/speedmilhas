export default function Admin() {
  return <div style={{ color: '#6B7280', fontSize: 14 }}>Admin — em construção.</div>
}
