import { useState } from 'react'
import { supabase } from '../lib/supabase'

const ADMIN_USER  = 'admin'
const ADMIN_PASS  = 'speed2026'
const ACCESS_CODE = 'SPEED2024'

export default function Login({ onLogin }) {
  const [cadastro, setCadastro] = useState(false)
  const [user,  setUser]  = useState('')
  const [pass,  setPass]  = useState('')
  const [nome,  setNome]  = useState('')
  const [code,  setCode]  = useState('')
  const [err,   setErr]   = useState('')

  async function fazerLogin() {
    setErr('')
    if (user === ADMIN_USER && pass === ADMIN_PASS) {
      onLogin({ username: ADMIN_USER, nome: 'Administrador', role: 'admin' })
      return
    }
    const { data } = await supabase
      .from('sm_users').select('*').eq('username', user).single()
    if (data && data.senha === btoa(pass)) {
      onLogin({ username: data.username, nome: data.nome, role: 'user' })
    } else {
      setErr('Usuário ou senha incorretos.')
    }
  }

  async function fazerCadastro() {
    setErr('')
    if (code !== ACCESS_CODE) { setErr('Código de acesso inválido.'); return }
    if (!nome || !user || !pass) { setErr('Preencha todos os campos.'); return }
    const { error } = await supabase
      .from('sm_users').insert({ username: user, nome, senha: btoa(pass) })
    if (error) { setErr('Erro: ' + error.message); return }
    onLogin({ username: user, nome, role: 'user' })
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex',
      alignItems: 'center', justifyContent: 'center', background: '#F5F6FA',
    }}>
      <div style={{
        background: '#fff', border: '1px solid #E5E7EB',
        borderRadius: 16, padding: '2rem 2.5rem',
        width: '100%', maxWidth: 400,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: '1.5rem' }}>
          <div style={{
            width: 44, height: 44, borderRadius: '50%',
            background: '#EFF6FF', display: 'flex',
            alignItems: 'center', justifyContent: 'center', fontSize: 22,
          }}>✈️</div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 600, color: '#111827' }}>Speed Milhas</div>
            <div style={{ fontSize: 13, color: '#6B7280' }}>Sistema de pós-vendas</div>
          </div>
        </div>

        {!cadastro ? (
          <>
            <Field label="Usuário" value={user} onChange={setUser} placeholder="seu.nome" />
            <Field label="Senha" value={pass} onChange={setPass} type="password" placeholder="••••••••" onEnter={fazerLogin} />
            {err && <p style={{ fontSize: 12, color: '#DC2626', marginBottom: 8 }}>{err}</p>}
            <Btn onClick={fazerLogin}>Entrar</Btn>
            <p style={{ fontSize: 13, color: '#6B7280', textAlign: 'center', marginTop: '1rem' }}>
              Não tem conta?{' '}
              <span style={{ color: '#1A56DB', cursor: 'pointer' }} onClick={() => { setCadastro(true); setErr('') }}>
                Criar acesso
              </span>
            </p>
          </>
        ) : (
          <>
            <Field label="Nome completo"    value={nome} onChange={setNome} placeholder="Maria Silva" />
            <Field label="Usuário"          value={user} onChange={setUser} placeholder="maria.silva" />
            <Field label="Senha"            value={pass} onChange={setPass} type="password" placeholder="mínimo 6 caracteres" />
            <Field label="Código de acesso" value={code} onChange={setCode} placeholder="Solicite ao administrador" />
            {err && <p style={{ fontSize: 12, color: '#DC2626', marginBottom: 8 }}>{err}</p>}
            <Btn onClick={fazerCadastro}>Criar conta</Btn>
            <p style={{ fontSize: 13, color: '#6B7280', textAlign: 'center', marginTop: '1rem' }}>
              <span style={{ color: '#1A56DB', cursor: 'pointer' }} onClick={() => { setCadastro(false); setErr('') }}>
                Voltar ao login
              </span>
            </p>
          </>
        )}
      </div>
    </div>
  )
}

function Field({ label, value, onChange, type = 'text', placeholder, onEnter }) {
  return (
    <div style={{ marginBottom: '1rem' }}>
      <label style={{ fontSize: 12, fontWeight: 500, color: '#374151', marginBottom: 5, display: 'block' }}>
        {label}
      </label>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={e => onChange(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && onEnter?.()}
        style={{
          width: '100%', padding: '10px 12px',
          border: '1px solid #D1D5DB', borderRadius: 8,
          fontSize: 14, color: '#111827', outline: 'none',
        }}
      />
    </div>
  )
}

function Btn({ children, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        width: '100%', padding: 11,
        background: '#1A56DB', color: '#fff',
        border: 'none', borderRadius: 8,
        fontSize: 14, fontWeight: 600, cursor: 'pointer',
      }}
    >
      {children}
    </button>
  )
}
