export default function Configuracoes() {
  return <div style={{ color: '#6B7280', fontSize: 14 }}>Configuracoes — em construção.</div>
}
