export default function Vendas() {
  return <div style={{ color: '#6B7280', fontSize: 14 }}>Vendas — em construção.</div>
}
