import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

export default function Retarificacao() {
  const user      = JSON.parse(sessionStorage.getItem('sm_user') || '{}')
  const isEmissor = user?.role === 'admin' || user?.username?.includes('emissor')

  const [tab,       setTab]       = useState('alertas')
  const [registros, setRegistros] = useState([])
  const [usuarios,  setUsuarios]  = useState([])
  const [filtro,    setFiltro]    = useState('todos')
  const [form,      setForm]      = useState({ op: '', cliente: '', atendente: '', valor: '' })

  useEffect(() => {
    carregar()
    const iv = setInterval(carregar, 5000)
    return () => clearInterval(iv)
  }, [])

  async function carregar() {
    const { data: recs } = await supabase
      .from('retarificacoes').select('*').order('created_at', { ascending: false })
    if (recs) setRegistros(recs)

    const { data: us } = await supabase
      .from('sm_users').select('nome, username')
    if (us) setUsuarios(us)
  }

  async function registrar() {
    if (!form.op || !form.cliente || !form.atendente || !form.valor) {
      alert('Preencha todos os campos!'); return
    }
    await supabase.from('retarificacoes').insert({
      op:         form.op,
      cliente:    form.cliente,
      atendente:  form.atendente,
      novo_valor: form.valor,
      emissor:    user.nome,
      status:     'pendente',
    })
    setForm({ op: '', cliente: '', atendente: '', valor: '' })
    carregar()
    setTab('alertas')
  }

  async function confirmar(id) {
    await supabase.from('retarificacoes').update({
      status:        'confirmado',
      confirmado_em: new Date().toISOString(),
      confirmado_por: user.nome,
    }).eq('id', id)
    carregar()
  }

  const alertas = isEmissor
    ? registros.filter(r => r.status === 'pendente')
    : registros.filter(r => r.atendente === user.nome && r.status === 'pendente')

  const filtrados = filtro === 'pendente'   ? registros.filter(r => r.status === 'pendente')
    : filtro === 'confirmado' ? registros.filter(r => r.status === 'confirmado')
    : filtro === 'hoje'       ? registros.filter(r => new Date(r.created_at).toDateString() === new Date().toDateString())
    : registros

  const tabs = ['alertas', isEmissor && 'registrar', 'historico'].filter(Boolean)

  return (
    <div style={{ maxWidth: 900 }}>

      {/* Aviso de pendências quando não está na aba alertas */}
      {alertas.length > 0 && tab !== 'alertas' && (
        <div style={{
          background: '#FEE2E2', border: '1px solid #FCA5A5',
          borderRadius: 8, padding: '10px 16px',
          marginBottom: 16, fontSize: 13, color: '#991B1B', fontWeight: 600,
        }}>
          🚨 {alertas.length} retarificação(ões) pendente(s)!
        </div>
      )}

      {/* Sub-tabs */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {tabs.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              padding: '7px 16px', borderRadius: 8,
              border: '1px solid #E5E7EB', cursor: 'pointer',
              background: tab === t ? '#EFF6FF' : '#fff',
              color:      tab === t ? '#1A56DB' : '#6B7280',
              fontWeight: tab === t ? 600 : 500,
              fontSize: 13,
            }}
          >
            {t === 'alertas' ? '🚨 Alertas' : t === 'registrar' ? '➕ Registrar' : '📋 Histórico'}
          </button>
        ))}
      </div>

      {/* ── ALERTAS ── */}
      {tab === 'alertas' && (
        <>
          {/* Status dos atendentes (só emissor/admin) */}
          {isEmissor && usuarios.length > 0 && (
            <div style={{
              background: '#fff', border: '1px solid #E5E7EB',
              borderRadius: 12, padding: 16, marginBottom: 16,
            }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#6B7280', textTransform: 'uppercase', marginBottom: 10 }}>
                Status dos atendentes
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 8 }}>
                {usuarios.map(u => {
                  const pend = registros.filter(r => r.atendente === u.nome && r.status === 'pendente').length
                  return (
                    <div key={u.username} style={{
                      background: pend > 0 ? '#FEF2F2' : '#F0FDF4',
                      border: `1px solid ${pend > 0 ? '#FCA5A5' : '#86EFAC'}`,
                      borderRadius: 8, padding: 10, textAlign: 'center',
                    }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: '#111827' }}>{u.nome}</div>
                      <div style={{ fontSize: 11, fontWeight: 600, color: pend > 0 ? '#DC2626' : '#15803D', marginTop: 2 }}>
                        {pend > 0 ? `⚠ ${pend} pendente(s)` : '✅ Em dia'}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {alertas.length === 0 ? (
            <div style={{
              background: '#F0FDF4', border: '1px solid #86EFAC',
              borderRadius: 10, padding: 20, textAlign: 'center',
              color: '#15803D', fontSize: 13, fontWeight: 500,
            }}>
              ✅ Nenhuma retarificação pendente para você.
            </div>
          ) : (
            alertas.map(r => (
              <AlertaCard key={r.id} r={r} isEmissor={isEmissor} onConfirmar={confirmar} />
            ))
          )}
        </>
      )}

      {/* ── REGISTRAR ── */}
      {tab === 'registrar' && isEmissor && (
        <div style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 12, padding: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: '#111827', marginBottom: 16 }}>
            🔴 Registrar nova retarificação
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <FF label="OP *"              value={form.op}      onChange={v => setForm(f => ({ ...f, op: v }))}      placeholder="Número da OP" />
            <FF label="Novo Valor (R$) *" value={form.valor}   onChange={v => setForm(f => ({ ...f, valor: v }))}   placeholder="Ex: 2.450,00" />
            <div style={{ gridColumn: '1/-1' }}>
              <FF label="Cliente *" value={form.cliente} onChange={v => setForm(f => ({ ...f, cliente: v }))} placeholder="Nome do cliente" />
            </div>
            <div style={{ gridColumn: '1/-1' }}>
              <label style={{ fontSize: 12, fontWeight: 500, color: '#374151', display: 'block', marginBottom: 4 }}>
                Atendente *
              </label>
              <select
                value={form.atendente}
                onChange={e => setForm(f => ({ ...f, atendente: e.target.value }))}
                style={{
                  width: '100%', padding: '7px 12px',
                  border: '1px solid #E5E7EB', borderRadius: 8,
                  fontSize: 13, background: '#F9FAFB', color: '#1F2937',
                }}
              >
                <option value="">Selecione...</option>
                {usuarios.map(u => (
                  <option key={u.username} value={u.nome}>{u.nome}</option>
                ))}
              </select>
            </div>
          </div>
          <button
            onClick={registrar}
            style={{
              width: '100%', padding: 11, marginTop: 12,
              background: '#DC2626', color: '#fff',
              border: 'none', borderRadius: 8,
              fontSize: 14, fontWeight: 600, cursor: 'pointer',
            }}
          >
            🚨 Registrar Retarificação
          </button>
        </div>
      )}

      {/* ── HISTÓRICO ── */}
      {tab === 'historico' && (
        <div style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 12, padding: 20 }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
            {['todos', 'pendente', 'confirmado', 'hoje'].map(f => (
              <button
                key={f}
                onClick={() => setFiltro(f)}
                style={{
                  padding: '5px 12px', borderRadius: 20, cursor: 'pointer',
                  border: '1px solid #E5E7EB',
                  background: filtro === f ? '#EFF6FF' : '#fff',
                  color:      filtro === f ? '#1A56DB' : '#6B7280',
                  fontWeight: filtro === f ? 600 : 400,
                  fontSize: 12,
                }}
              >
                {{ todos: 'Todos', pendente: 'Pendentes', confirmado: 'Confirmados', hoje: 'Hoje' }[f]}
              </button>
            ))}
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr>
                  {['Data', 'OP', 'Cliente', 'Novo Valor', 'Emissor', 'Atendente', 'Status', 'Confirmado em'].map(h => (
                    <th key={h} style={{
                      fontSize: 10, color: '#9CA3AF', padding: '8px 10px',
                      textAlign: 'left', fontWeight: 600,
                      textTransform: 'uppercase', borderBottom: '2px solid #E5E7EB',
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtrados.length === 0 ? (
                  <tr><td colSpan={8} style={{ padding: 20, textAlign: 'center', color: '#9CA3AF' }}>Nenhum registro.</td></tr>
                ) : filtrados.map(r => (
                  <tr key={r.id} style={{ borderBottom: '1px solid #F3F4F6' }}>
                    <td style={{ padding: '8px 10px', color: '#374151' }}>{new Date(r.created_at).toLocaleString('pt-BR')}</td>
                    <td style={{ padding: '8px 10px', fontWeight: 600 }}>{r.op}</td>
                    <td style={{ padding: '8px 10px' }}>{r.cliente}</td>
                    <td style={{ padding: '8px 10px', fontWeight: 600 }}>R$ {r.novo_valor}</td>
                    <td style={{ padding: '8px 10px' }}>{r.emissor}</td>
                    <td style={{ padding: '8px 10px' }}>{r.atendente}</td>
                    <td style={{ padding: '8px 10px' }}>
                      <span style={{
                        background: r.status === 'pendente' ? '#FEE2E2' : '#DCFCE7',
                        color:      r.status === 'pendente' ? '#991B1B' : '#15803D',
                        fontSize: 11, fontWeight: 600, padding: '3px 8px', borderRadius: 6,
                      }}>
                        {r.status === 'pendente' ? 'Pendente' : 'Confirmado'}
                      </span>
                    </td>
                    <td style={{ padding: '8px 10px', color: '#9CA3AF' }}>
                      {r.confirmado_em ? new Date(r.confirmado_em).toLocaleString('pt-BR') : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

function AlertaCard({ r, isEmissor, onConfirmar }) {
  return (
    <div style={{
      background: '#FEF2F2', border: '2px solid #FCA5A5',
      borderRadius: 12, padding: 18, marginBottom: 12,
    }}>
      <div style={{ fontSize: 14, fontWeight: 700, color: '#991B1B', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 8 }}>
        🚨 VOO RETARIFOU!
        <span style={{ background: '#DC2626', color: '#fff', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 99 }}>
          URGENTE
        </span>
      </div>
      <div style={{ fontSize: 11, color: '#6B7280', marginBottom: 10 }}>
        Registrado por: {r.emissor} • Para: <strong>{r.atendente}</strong>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
        <InfoItem label="OP"         value={r.op} />
        <InfoItem label="Novo Valor" value={`R$ ${r.novo_valor}`} />
        <InfoItem label="Cliente"    value={r.cliente} full />
      </div>
      {!isEmissor && (
        <button
          onClick={() => onConfirmar(r.id)}
          style={{
            width: '100%', padding: 10,
            background: '#15803D', color: '#fff',
            border: 'none', borderRadius: 8,
            fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}
        >
          ✅ Avisei o cliente — Remover alerta
        </button>
      )}
    </div>
  )
}

function InfoItem({ label, value, full }) {
  return (
    <div style={full ? { gridColumn: '1/-1' } : {}}>
      <div style={{ fontSize: 11, color: '#6B7280', marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>{value}</div>
    </div>
  )
}

function FF({ label, value, onChange, placeholder }) {
  return (
    <div>
      <label style={{ fontSize: 12, fontWeight: 500, color: '#374151', display: 'block', marginBottom: 4 }}>
        {label}
      </label>
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: '100%', padding: '7px 12px',
          border: '1px solid #E5E7EB', borderRadius: 8,
          fontSize: 13, background: '#F9FAFB', color: '#1F2937', outline: 'none',
        }}
      />
    </div>
  )
}
