export default function Atendimento() {
  return <div style={{ color: '#6B7280', fontSize: 14 }}>Atendimento — em construção.</div>
}
