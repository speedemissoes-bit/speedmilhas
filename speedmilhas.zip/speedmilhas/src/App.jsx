import { useState, useEffect } from 'react'
import Login from './pages/Login'
import Layout from './components/Layout'
import Vendas from './pages/Vendas'
import Boleto from './pages/Boleto'
import Atendimento from './pages/Atendimento'
import Followup from './pages/Followup'
import Retarificacao from './pages/Retarificacao'
import Admin from './pages/Admin'
import Configuracoes from './pages/Configuracoes'

export default function App() {
  const [user, setUser] = useState(null)
  const [page, setPage] = useState('vendas')

  useEffect(() => {
    const saved = sessionStorage.getItem('sm_user')
    if (saved) setUser(JSON.parse(saved))
  }, [])

  function handleLogin(u) {
    sessionStorage.setItem('sm_user', JSON.stringify(u))
    setUser(u)
  }

  function handleLogout() {
    sessionStorage.removeItem('sm_user')
    setUser(null)
  }

  if (!user) return <Login onLogin={handleLogin} />

  const pages = {
    vendas: <Vendas />,
    boleto: <Boleto />,
    atendimento: <Atendimento />,
    followup: <Followup />,
    retarificacao: <Retarificacao />,
    admin: <Admin />,
    configuracoes: <Configuracoes />,
  }

  return (
    <Layout user={user} page={page} setPage={setPage} onLogout={handleLogout}>
      {pages[page] || <Vendas />}
    </Layout>
  )
}
